// Since the DDK's nmake is limited with directories, we will bypass that with this simple hack.
// Thanks to Razvan Hobeanu.
// Sep 2009.


#include "../src/mnemonics.c"
#include "../src/wstring.c"
#include "../src/textdefs.c"
#include "../src/x86defs.c"
#include "../src/prefix.c"
#include "../src/operands.c"
#include "../src/insts.c"
#include "../src/instructions.c"
#include "../src/distorm.c"
#include "../src/decoder.c"
